<?php
$stationCount = 25;
$station[0] = "Andrea Bocelli Radio";
$station[1] = "Apocalyptica Radio";
$station[2] = "Coding Music";
$station[3] = "Dave Mathews";
$station[4] = "David Lanz Radio";
$station[5] = "Electronic Dance";
$station[6] = "Evanescence Radio";
$station[7] = "Flight Of The Conchords Radio";
$station[8] = "Gorillaz Radio";
$station[9] = "In Your Eyes Radio";
$station[10] = "kansas";
$station[11] = "Kicking Fun";
$station[12] = "Little People Radio";
$station[13] = "Maynard Ferguson Orchestra Radio";
$station[14] = "My Blues";
$station[15] = "Never There Radio";
$station[16] = "New Age";
$station[17] = "Queen Radio";
$station[18] = "QuickMix";
$station[19] = "Rockapella Radio";
$station[20] = "Rural Wisconsin";
$station[21] = "Talking Heads Radio";
$station[22] = "The Ting Tings Radio";
$station[23] = "Wolfgang Amadeus Mozart Radio";
$station[24] = "Yaz Radio";
?>
