<?php

#phpinfo();
if ( $_POST["station"] != "" ) {
	$res = file_put_contents("/home/pi/.config/pianobar/ctl", "s");
	$res = file_put_contents("/home/pi/.config/pianobar/ctl", $_POST["station"]);
	$res = file_put_contents("/home/pi/.config/pianobar/ctl", "\n");
	sleep(4);
}

if ( $_POST["love"] != "" ) {
	$res = file_put_contents("/home/pi/.config/pianobar/ctl", "+");
	sleep(3);
}

if ( $_POST["ban"] != "" ) {
	$res = file_put_contents("/home/pi/.config/pianobar/ctl", "-");
	sleep(3);
}

if ( $_POST["skip"] != "" ) {
	$res = file_put_contents("/home/pi/.config/pianobar/ctl", "n");
	sleep(3);
}

if ( $_POST["quit"] != "" ) {
	$res = file_put_contents("/home/pi/.config/pianobar/ctl", "q");
	sleep(3);
}

if ( $_POST["start"] != "" ) {
	system("touch /tmp/start_pianobar");
	sleep(15);
	system("rm /tmp/start_pianobar");
}

if ( $_POST["volup"] != "" ) {
	$res = file_put_contents("/home/pi/.config/pianobar/ctl", ")");
}

if ( $_POST["voldwn"] != "" ) {
	$res = file_put_contents("/home/pi/.config/pianobar/ctl", "(");
}

header("Location:index.php");
?>
