<?php
$artist = "The Chemical Brothers";
$title = "The Devil Is In The Beats";
$album = "Hanna (Original Motion Picture Soundtrack)";
$coverArt = "http://cont-sv5-3.pandora.com/images/public/amz/6/6/9/0/800010966_500W_500H.jpg";
$stationName = "Electronic Dance";
$rating = "0";
?>
